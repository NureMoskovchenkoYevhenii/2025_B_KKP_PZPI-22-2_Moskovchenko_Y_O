﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;


public class User
{
    public int UserId { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string PhoneNumber { get; set; }
    public string Role { get; set; }
    public string PasswordHash { get; set; }
    public ICollection<UserWorkingDay> UserWorkingDays { get; set; } = new List<UserWorkingDay>();
    public ICollection<UserChangeRequest> UserChangeRequests { get; set; } = new List<UserChangeRequest>();

}



public class DayType
{
    public int DayTypeId { get; set; }
    public string DayTypeName { get; set; }
    public ICollection<WorkingDay> WorkingDays { get; set; }
    public ICollection<ChangeRequest> ChangeRequests { get; set; }
}

public class WorkingDay
{
    public int WorkingDayId { get; set; }
    public DateTime StartTime { get; set; } 
    public DateTime EndTime { get; set; }   
    public int DayTypeId { get; set; }
    
    public DayType? DayType { get; set; }

    public ICollection<UserWorkingDay> UserWorkingDays { get; set; } = new List<UserWorkingDay>();
}


public class UserWorkingDay
{
    public int UserWorkingDayId { get; set; }
    public int UserId { get; set; }
    public User User { get; set; }
    public int WorkingDayId { get; set; }
    public WorkingDay WorkingDay { get; set; }
}
public class ChangeRequest
{
    public int ChangeRequestId { get; set; }
    public DateTime RequestDate { get; set; }
    public string Status { get; set; }

    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public string Description { get; set; }
    public int DayTypeId { get; set; }
    public DayType? DayType { get; set; }
    public ICollection<UserChangeRequest> UserChangeRequests { get; set; } = new List<UserChangeRequest>();
    public ChangeRequest()
    {
        Status = "на опрацюванні";
    }
}



public class UserChangeRequest
{
    public int UserChangeRequestId { get; set; }
    public int UserId { get; set; }
    public User User { get; set; }
    public int ChangeRequestId { get; set; }
    public ChangeRequest ChangeRequest { get; set; }
    
}



[Table("SensorData")]
public class SensorData
{
    [Column("id")]
    public int Id { get; set; }

    [Column("timestamp")]
    public DateTime Timestamp { get; set; } = DateTime.Now;

    [Column("temperature")]
    public decimal Temperature { get; set; }

    [Column("humidity")]
    public decimal Humidity { get; set; }

    [Column("IsTemperatureAdjustmentEnabled")]
    public bool IsTemperatureAdjustmentEnabled { get; set; } 

    [Column("IsHumidityAdjustmentEnabled")]
    public bool IsHumidityAdjustmentEnabled { get; set; } 
}

public class UserWorkingDayDto
{
    public int UserWorkingDayId { get; set; }
    public int UserId { get; set; }
    public int WorkingDayId { get; set; }
    public WorkingDayDto WorkingDay { get; set; }
    
}
public class DayTypeDto
{
    public int DayTypeId { get; set; }
    public string DayTypeName { get; set; }
}
public class WorkingDayDto
{
    public int WorkingDayId { get; set; }
    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }
    public int DayTypeId { get; set; }
    public DayTypeDto DayType { get; set; }
    public int UserId { get; set; }

}
public class ChangeRequestDto
{
    public int ChangeRequestId { get; set; }
    public DateTime RequestDate { get; set; }
    public string Status { get; set; }
    public int DayTypeId { get; set; }
    public int UserId { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public string Description { get; set; }

    public DayTypeDto? DayType { get; set; }
    public List<UserChangeRequestDto>? UserChangeRequests { get; set; }
}

public class SensorDataDto
{
    public int Id { get; set; }
    public DateTime Timestamp { get; set; }
    public decimal Temperature { get; set; }
    public decimal Humidity { get; set; }
    public bool IsTemperatureAdjustmentEnabled { get; set; }
    public bool IsHumidityAdjustmentEnabled { get; set; }
}
public class UserChangeRequestDto
{
    public int UserChangeRequestId { get; set; }
    public int UserId { get; set; }
    public int ChangeRequestId { get; set; }
    public UserDto? User { get; set; }
}
public class UserDto
{
    public int UserId { get; set; }
    [Required(ErrorMessage = "The FirstName field is required.")]
    [RegularExpression(@"^[\p{L}\p{M}'-]+$", ErrorMessage = "First name can only contain letters and hyphens.")]
    public string FirstName { get; set; } = string.Empty;

    [Required(ErrorMessage = "The LastName field is required.")]
    [RegularExpression(@"^[\p{L}\p{M}'-]+$", ErrorMessage = "Last name can only contain letters and hyphens.")]
    public string LastName { get; set; } = string.Empty;
    [Required]
    [RegularExpression(@"^380\d{9}$", ErrorMessage = "Phone number must be in the format 380XXXXXXXXX")]
    public string PhoneNumber { get; set; } = string.Empty;
    public string Role { get; set; }
    public string? Password { get; set; } 
}

public class LoginDto
{
    public string PhoneNumber { get; set; } 
    public string Password { get; set; }
}
public class UserUpdateDto
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string Role { get; set; }
}

public class ChangeRequestUpdateDto
{
    public string Status { get; set; }
}
public class CreateWorkingDayDto
{
    public int UserId { get; set; }
    public int DayTypeId { get; set; }
    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }
}