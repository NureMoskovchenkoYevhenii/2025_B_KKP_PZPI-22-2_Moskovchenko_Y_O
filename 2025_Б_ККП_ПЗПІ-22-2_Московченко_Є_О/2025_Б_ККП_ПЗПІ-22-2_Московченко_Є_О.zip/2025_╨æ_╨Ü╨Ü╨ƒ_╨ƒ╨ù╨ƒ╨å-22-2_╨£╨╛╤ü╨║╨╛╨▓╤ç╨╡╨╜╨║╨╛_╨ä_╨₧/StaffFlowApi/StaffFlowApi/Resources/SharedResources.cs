public class SharedResources
{
}