using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

public class BackupService
{
    private readonly IConfiguration _configuration;

    private readonly string _backupsDirectory = "/backups";
    public BackupService(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public async Task<(bool Success, string Message)> CreateBackupAsync()
    {
        var connectionString = _configuration.GetConnectionString("DefaultConnection");

        var settings = connectionString.Split(';')
            .Select(s => s.Split('='))
            .ToDictionary(a => a[0].Trim(), a => a[1].Trim());

        var host = settings["Host"];
        var port = settings["Port"];
        var database = settings["Database"];
        var username = settings["Username"];
        var password = settings["Password"];

        var backupFileName = $"backup_{DateTime.UtcNow:yyyyMMdd_HHmmss}.sql";
        var backupFilePath = $"/backups/{backupFileName}";

        var process = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = "pg_dump",
                Arguments = $"--clean --if-exists -h {host} -p {port} -U {username} -d {database} -f {backupFilePath}",
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true,
            }
        };

        process.StartInfo.EnvironmentVariables["PGPASSWORD"] = password;

        process.Start();
        string error = await process.StandardError.ReadToEndAsync();
        await process.WaitForExitAsync();

        if (process.ExitCode == 0)
        {
            return (true, $"Clean backup created successfully: {backupFileName}");
        }
        else
        {
            return (false, $"Error creating backup: {error}");
        }
    }

    public IEnumerable<string> GetAvailableBackups()
    {
        if (!Directory.Exists(_backupsDirectory))
        {
            return Enumerable.Empty<string>();
        }

        return Directory.GetFiles(_backupsDirectory, "*.sql")
                        .Select(Path.GetFileName)
                        .OrderByDescending(f => f);
    }

    public async Task<(bool Success, string Message)> RestoreBackupAsync(string backupFileName)
    {
        var backupFilePath = Path.Combine(_backupsDirectory, backupFileName);

        if (!File.Exists(backupFilePath))
        {
            return (false, $"Backup file not found: {backupFileName}");
        }

        var connectionString = _configuration.GetConnectionString("DefaultConnection");
        var settings = connectionString.Split(';')
            .Select(s => s.Split('='))
            .ToDictionary(a => a[0].Trim(), a => a[1].Trim());

        var host = settings["Host"];
        var port = settings["Port"];
        var database = settings["Database"];
        var username = settings["Username"];
        var password = settings["Password"];

        var process = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = "psql",
                Arguments = $"--single-transaction -h {host} -U {username} -d {database} -f {backupFilePath}",
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true,
            }
        };

        process.StartInfo.EnvironmentVariables["PGPASSWORD"] = password;

        process.Start();
        string error = await process.StandardError.ReadToEndAsync();
        await process.WaitForExitAsync();

        if (process.ExitCode == 0)
        {
            return (true, $"Restore from {backupFileName} completed successfully.");
        }
        else
        {
            return (false, $"Error restoring from backup: {error}");
        }
    }
    
}