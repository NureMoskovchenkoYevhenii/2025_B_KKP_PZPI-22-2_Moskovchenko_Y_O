﻿using Microsoft.Extensions.Localization;

public class WorkingDayService
{
    private readonly IWorkingDayRepository _workingDayRepository;
    private readonly IUserWorkingDayRepository _userWorkingDayRepository;
    private readonly IStringLocalizer<SharedResources> _localizer;

    public WorkingDayService(
        IWorkingDayRepository workingDayRepository,
        IUserWorkingDayRepository userWorkingDayRepository,
        IStringLocalizer<SharedResources> localizer)
    {
        _workingDayRepository = workingDayRepository;
        _userWorkingDayRepository = userWorkingDayRepository;
        _localizer = localizer;
    }

    public async Task<WorkingDay> AddWorkingDayAsync(CreateWorkingDayDto createDto)
    {
        var newWorkingDay = new WorkingDay
        {
            StartTime = DateTime.SpecifyKind(createDto.StartTime, DateTimeKind.Utc),
            EndTime = DateTime.SpecifyKind(createDto.EndTime, DateTimeKind.Utc),
            DayTypeId = createDto.DayTypeId
        };

        var createdWorkingDay = await _workingDayRepository.AddAsync(newWorkingDay);

        var userWorkingDay = new UserWorkingDay
        {
            UserId = createDto.UserId,
            WorkingDayId = createdWorkingDay.WorkingDayId
        };
        await _userWorkingDayRepository.AddAsync(userWorkingDay);

        return createdWorkingDay;
    }

    public async Task<IEnumerable<WorkingDay>> GetAllWorkingDaysAsync()
    {
        return await _workingDayRepository.GetAllAsync();
    }

    public async Task<WorkingDay> GetWorkingDayByIdAsync(int workingDayId)
    {
        return await _workingDayRepository.GetByIdAsync(workingDayId);
    }

    public async Task UpdateWorkingDayAsync(int workingDayId, WorkingDayDto updatedWorkingDayDto)
    {
        var workingDay = await _workingDayRepository.GetByIdAsync(workingDayId);
        if (workingDay != null)
        {
            workingDay.StartTime = DateTime.SpecifyKind(updatedWorkingDayDto.StartTime, DateTimeKind.Utc);
            workingDay.EndTime = DateTime.SpecifyKind(updatedWorkingDayDto.EndTime, DateTimeKind.Utc);
            workingDay.DayTypeId = updatedWorkingDayDto.DayTypeId;
            
            await _workingDayRepository.UpdateAsync(workingDay);
        }
    }

    public async Task DeleteWorkingDayAsync(int workingDayId)
    {
        await _workingDayRepository.DeleteAsync(workingDayId);
    }
     public async Task<IEnumerable<UserWorkingDay>> GetScheduleForUserAsync(int userId)
    {
        return await _userWorkingDayRepository.GetByUserIdAsync(userId);
    }
}