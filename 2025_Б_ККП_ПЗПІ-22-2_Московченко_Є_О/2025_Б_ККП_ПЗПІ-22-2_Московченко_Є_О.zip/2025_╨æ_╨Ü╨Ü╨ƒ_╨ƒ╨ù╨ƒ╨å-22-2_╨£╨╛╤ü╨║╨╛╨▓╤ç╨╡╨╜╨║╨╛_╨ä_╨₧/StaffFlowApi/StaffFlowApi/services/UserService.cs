﻿using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using System;
using Microsoft.Extensions.Localization;
using System.Security.Claims;
using BCrypt.Net;

public class UserService
{
    private readonly IUserRepository _userRepository;
    private readonly IStringLocalizer<SharedResources> _localizer;
    public UserService(IUserRepository userRepository, IStringLocalizer<SharedResources> localizer)
    {
        _userRepository = userRepository;
        _localizer = localizer;
    }
    public async Task<User> Authenticate(string username, string password)
    {
        var user = await _userRepository.FindByUsernameAsync(username);

        if (user == null || !BCrypt.Net.BCrypt.Verify(password, user.PasswordHash))
        {
            return null;
        }

        return user;
    }
    public async Task<User> AddUserAsync(User user)
    {
        user.PhoneNumber = new string(user.PhoneNumber.Where(char.IsDigit).ToArray());

        var existingUser = await _userRepository.FindByUsernameAsync(user.PhoneNumber);
        if (existingUser != null)
        {
            throw new Exception(_localizer["PhoneNumberExists"]);
        }

        return await _userRepository.AddAsync(user);
    }
    public async Task<IEnumerable<User>> GetAllUsersAsync()
    {
        return await _userRepository.GetAllAsync();
    }
    public async Task<User> GetUserByIdAsync(int userId)
    {
        return await _userRepository.GetByIdAsync(userId);
    }
    public async Task UpdateUserAsync(int userIdToUpdate, UserUpdateDto userUpdateDto, ClaimsPrincipal currentUser)
    {
        var currentUserId = int.Parse(currentUser.FindFirstValue(ClaimTypes.NameIdentifier));

        var userToUpdate = await _userRepository.GetByIdAsync(userIdToUpdate);
        if (userToUpdate == null)
        {
            throw new Exception(_localizer["UserNotFound"]);
        }

        if (userToUpdate.UserId == currentUserId && userToUpdate.Role != userUpdateDto.Role)
        {
            throw new InvalidOperationException(_localizer["AdminCannotChangeOwnRole"]);
        }

        userToUpdate.FirstName = userUpdateDto.FirstName;
        userToUpdate.LastName = userUpdateDto.LastName;
        userToUpdate.Role = userUpdateDto.Role;
        await _userRepository.UpdateAsync(userToUpdate);
    }

    public async Task DeleteUserAsync(int userIdToDelete, ClaimsPrincipal currentUser)
    {
        var currentUserId = int.Parse(currentUser.FindFirstValue(ClaimTypes.NameIdentifier));

        if (userIdToDelete == currentUserId)
        {
            throw new InvalidOperationException(_localizer["AdminCannotDeleteSelf"]);
        }

        await _userRepository.DeleteAsync(userIdToDelete);
    }


    public async Task<string> GenerateUserWorkingDaysReport(int userId)
    {
        var user = await _userRepository.GetByIdAsync(userId);
        if (user == null)
        {
            throw new Exception(_localizer["UserNotFound"]);
        }

        var report = $"Report for {user.FirstName} {user.LastName}\n";

        var lastWeekWorkingDays = user.UserWorkingDays?
            .Where(uwd => uwd.WorkingDay.StartTime >= DateTime.Now.AddDays(-7))
            .ToList() ?? new List<UserWorkingDay>();

        double totalHours = 0;
        foreach (var workingDay in lastWeekWorkingDays)
        {
            var hours = (workingDay.WorkingDay.EndTime - workingDay.WorkingDay.StartTime).TotalHours;
            totalHours += hours;
            report += $"Date: {workingDay.WorkingDay.StartTime.ToShortDateString()}, " +
            $"Start: {workingDay.WorkingDay.StartTime.ToShortTimeString()}, " +
            $"End: {workingDay.WorkingDay.EndTime.ToShortTimeString()}, " +
            $"Hours: {hours}\n";
        }
        report += $"Total Hours in Last 7 Days: {totalHours}\n";

        var userChangeRequests = user.UserChangeRequests ?? new List<UserChangeRequest>();
        report += "Change Requests:\n";
        foreach (var userChangeRequest in userChangeRequests)
        {
            var request = userChangeRequest.ChangeRequest;
            report += $"Request Date: {request.RequestDate.ToShortDateString()}, " +
            $"Status: {request.Status}, " +
            $"Description: {request.Description}\n";
        }

        return report;
    }
}
