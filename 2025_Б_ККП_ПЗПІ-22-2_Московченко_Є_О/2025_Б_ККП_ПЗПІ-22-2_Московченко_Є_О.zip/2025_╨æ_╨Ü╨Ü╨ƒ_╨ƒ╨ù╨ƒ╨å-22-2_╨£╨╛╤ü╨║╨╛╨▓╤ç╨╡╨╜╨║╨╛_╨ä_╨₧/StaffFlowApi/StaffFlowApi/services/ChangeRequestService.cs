﻿using Microsoft.Extensions.Localization;

public class ChangeRequestService
{
     private readonly IChangeRequestRepository _changeRequestRepository;
    private readonly IUserChangeRequestRepository _userChangeRequestRepository;
    private readonly IWorkingDayRepository _workingDayRepository;
    private readonly IUserWorkingDayRepository _userWorkingDayRepository;
    private readonly IStringLocalizer<SharedResources> _localizer;

    public ChangeRequestService(
        IChangeRequestRepository changeRequestRepository,
        IUserChangeRequestRepository userChangeRequestRepository,
        IWorkingDayRepository workingDayRepository,
        IUserWorkingDayRepository userWorkingDayRepository,
        IStringLocalizer<SharedResources> localizer)
    {
        _changeRequestRepository = changeRequestRepository;
        _userChangeRequestRepository = userChangeRequestRepository;
        _workingDayRepository = workingDayRepository;
        _userWorkingDayRepository = userWorkingDayRepository;
        _localizer = localizer;
    }

    public async Task<ChangeRequest> AddChangeRequestAsync(ChangeRequest changeRequest, int userId)
    {
        var createdRequest = await _changeRequestRepository.AddAsync(changeRequest);

        var userChangeRequest = new UserChangeRequest
        {
            UserId = userId,
            ChangeRequestId = createdRequest.ChangeRequestId
        };

        await _userChangeRequestRepository.AddAsync(userChangeRequest);
        return createdRequest;
    }
    

    public async Task<IEnumerable<ChangeRequest>> GetAllChangeRequestsAsync()
    {
        return await _changeRequestRepository.GetAllAsync();
    }

    public async Task<ChangeRequest> GetChangeRequestByIdAsync(int changeRequestId)
    {
        return await _changeRequestRepository.GetByIdAsync(changeRequestId);
    }

    public async Task UpdateChangeRequestAsync(int changeRequestId, ChangeRequest updatedChangeRequest)
    {
        var changeRequest = await _changeRequestRepository.GetByIdAsync(changeRequestId);
        if (changeRequest != null)
        {
            changeRequest.Status = updatedChangeRequest.Status;
            await _changeRequestRepository.UpdateAsync(changeRequest);
        }
    }

    public async Task DeleteChangeRequestAsync(int changeRequestId)
    {
        await _changeRequestRepository.DeleteAsync(changeRequestId);
    }
    public async Task UpdateChangeRequestStatusAsync(int changeRequestId, string newStatus)
    {
        var changeRequest = await _changeRequestRepository.GetByIdAsync(changeRequestId);

        if (changeRequest != null)
        {
            changeRequest.Status = newStatus;
            await _changeRequestRepository.UpdateAsync(changeRequest);

            if (newStatus == "Схвалено")
            {
                var userId = changeRequest.UserChangeRequests.FirstOrDefault()?.UserId;
                if (userId.HasValue)
                {
                    await _userWorkingDayRepository.DeleteByUserIdAndDateRangeAsync(userId.Value, changeRequest.StartDate, changeRequest.EndDate);

                    for (var day = changeRequest.StartDate.Date; day.Date <= changeRequest.EndDate.Date; day = day.AddDays(1))
                    {
                        var newWorkingDay = new WorkingDay
                        {
                            StartTime = day,
                            EndTime = day.AddHours(23).AddMinutes(59),
                            DayTypeId = changeRequest.DayTypeId
                        };

                        var createdWorkingDay = await _workingDayRepository.AddAsync(newWorkingDay);
                        var userWorkingDay = new UserWorkingDay
                        {
                            UserId = userId.Value,
                            WorkingDayId = createdWorkingDay.WorkingDayId
                        };
                        await _userWorkingDayRepository.AddAsync(userWorkingDay);

                    }
                    
                }
            }
        }
    }
}