﻿using static BCrypt.Net.BCrypt;

public class UserMapper
{
    public UserDto MapToDto(User user)
    {
        return new UserDto
        {
            UserId = user.UserId,
            FirstName = user.FirstName,
            LastName = user.LastName,
            PhoneNumber = user.PhoneNumber,
            Role = user.Role
        };
    }


    public User MapToEntity(UserDto userDto)
    {
        var user = new User
        {
            UserId = userDto.UserId,
            FirstName = userDto.FirstName,
            LastName = userDto.LastName,
            PhoneNumber = new string(userDto.PhoneNumber.Where(char.IsDigit).ToArray()),
            Role = userDto.Role ?? "User", 
        };

        if (!string.IsNullOrEmpty(userDto.Password))
        {
            user.PasswordHash = HashPassword(userDto.Password);
        }
        
        return user;
    }

    private string HashPassword(string password)
    {
        return BCrypt.Net.BCrypt.HashPassword(password);
    }
}


