﻿public class WorkingDayMapper
{
    public WorkingDayDto MapToDto(WorkingDay workingDay)
    {
        return new WorkingDayDto
        {
            WorkingDayId = workingDay.WorkingDayId,
            StartTime = workingDay.StartTime,
            EndTime = workingDay.EndTime,   
            DayTypeId = workingDay.DayTypeId
        };
    }

   
   
}



