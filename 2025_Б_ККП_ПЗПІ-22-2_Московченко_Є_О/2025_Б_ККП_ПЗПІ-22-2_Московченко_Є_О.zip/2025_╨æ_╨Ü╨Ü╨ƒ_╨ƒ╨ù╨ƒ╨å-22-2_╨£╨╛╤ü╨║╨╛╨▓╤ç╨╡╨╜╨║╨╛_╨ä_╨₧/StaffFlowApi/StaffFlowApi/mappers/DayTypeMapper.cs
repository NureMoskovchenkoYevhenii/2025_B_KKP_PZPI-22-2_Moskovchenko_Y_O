﻿public class DayTypeMapper
{
    public DayTypeDto MapToDto(DayType dayType)
    {
        return new DayTypeDto
        {
            DayTypeId = dayType.DayTypeId,
            DayTypeName = dayType.DayTypeName
        };
    }

    public DayType MapToEntity(DayTypeDto dayTypeDto)
    {
        return new DayType
        {
            DayTypeId = dayTypeDto.DayTypeId,
            DayTypeName = dayTypeDto.DayTypeName
        };
    }
}


