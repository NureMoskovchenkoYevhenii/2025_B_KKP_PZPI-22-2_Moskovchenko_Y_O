﻿public class UserWorkingDayMapper
{
    public UserWorkingDayDto MapToDto(UserWorkingDay userWorkingDay)
    {
        if (userWorkingDay == null) return null;

        return new UserWorkingDayDto
        {
            UserWorkingDayId = userWorkingDay.UserWorkingDayId,
            UserId = userWorkingDay.UserId,
            WorkingDayId = userWorkingDay.WorkingDayId,
            WorkingDay = userWorkingDay.WorkingDay != null ? new WorkingDayDto
            {
                WorkingDayId = userWorkingDay.WorkingDay.WorkingDayId,
                StartTime = userWorkingDay.WorkingDay.StartTime,
                EndTime = userWorkingDay.WorkingDay.EndTime,
                DayTypeId = userWorkingDay.WorkingDay.DayTypeId,
                DayType = userWorkingDay.WorkingDay.DayType != null ? new DayTypeDto
                {
                    DayTypeId = userWorkingDay.WorkingDay.DayType.DayTypeId,
                    DayTypeName = userWorkingDay.WorkingDay.DayType.DayTypeName
                } : null
            } : null
        };
    }

    public UserWorkingDay MapToEntity(UserWorkingDayDto userWorkingDayDto)
    {
        return new UserWorkingDay
        {
            UserWorkingDayId = userWorkingDayDto.UserWorkingDayId,
            UserId = userWorkingDayDto.UserId,
            WorkingDayId = userWorkingDayDto.WorkingDayId
        };
    }
}


