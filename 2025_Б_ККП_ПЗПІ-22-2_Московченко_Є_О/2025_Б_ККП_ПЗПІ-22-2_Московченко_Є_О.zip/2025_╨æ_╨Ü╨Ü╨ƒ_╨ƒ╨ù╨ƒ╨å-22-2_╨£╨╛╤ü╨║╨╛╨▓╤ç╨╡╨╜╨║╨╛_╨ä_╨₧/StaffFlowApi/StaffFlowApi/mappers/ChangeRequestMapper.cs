﻿using System.ComponentModel.DataAnnotations;

public class ChangeRequestMapper
{
    public ChangeRequestDto MapToDto(ChangeRequest changeRequest)
    {
        if (changeRequest == null)
        {
            return null; 
        }
        var changeRequestDto = new ChangeRequestDto
        {
            ChangeRequestId = changeRequest.ChangeRequestId,
            RequestDate = changeRequest.RequestDate,
            Status = changeRequest.Status,
            DayTypeId = changeRequest.DayTypeId,
            StartDate = changeRequest.StartDate,
            EndDate = changeRequest.EndDate,
            Description = changeRequest.Description,
            
            DayType = changeRequest.DayType != null 
                ? new DayTypeDto
                {
                    DayTypeId = changeRequest.DayType.DayTypeId,
                    DayTypeName = changeRequest.DayType.DayTypeName
                } 
                : null, 
            UserChangeRequests = new List<UserChangeRequestDto>() 
        };

        if (changeRequest.UserChangeRequests != null && changeRequest.UserChangeRequests.Any())
        {
            var firstUserRequest = changeRequest.UserChangeRequests.First();
            if (firstUserRequest.User != null)
            {
                changeRequestDto.UserId = firstUserRequest.User.UserId;
                var userChangeRequestDto = new UserChangeRequestDto
                {
                    UserChangeRequestId = firstUserRequest.UserChangeRequestId,
                    UserId = firstUserRequest.UserId,
                    ChangeRequestId = firstUserRequest.ChangeRequestId,
                    User = new UserDto
                    {
                        UserId = firstUserRequest.User.UserId,
                        FirstName = firstUserRequest.User.FirstName,
                        LastName = firstUserRequest.User.LastName,
                        PhoneNumber = firstUserRequest.User.PhoneNumber,
                        Role = firstUserRequest.User.Role
                    }
                };
                changeRequestDto.UserChangeRequests.Add(userChangeRequestDto);
            }
        }
        return changeRequestDto;
    }


    public ChangeRequest MapToEntity(ChangeRequestDto changeRequestDto)
    {
        return new ChangeRequest
        {
            RequestDate = DateTime.UtcNow, 
            Status = changeRequestDto.Status,
            DayTypeId = changeRequestDto.DayTypeId,
            
            StartDate = DateTime.SpecifyKind(changeRequestDto.StartDate, DateTimeKind.Utc),
            EndDate = DateTime.SpecifyKind(changeRequestDto.EndDate, DateTimeKind.Utc),
            
            Description = changeRequestDto.Description
        };
    }
}



