﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using System.Linq;
using System.Threading.Tasks;
using System.Security.Claims;
using BCrypt.Net;

[Route("api/[controller]")]
[Authorize]
public class UsersController : ControllerBase
{
    private readonly UserService _userService;
    private readonly UserMapper _userMapper;
    private readonly IStringLocalizer<SharedResources> _localizer;

    public UsersController(UserService userService, UserMapper userMapper, IStringLocalizer<SharedResources> localizer)
    {
        _userService = userService;
        _userMapper = userMapper;
        _localizer = localizer;
    }

    [HttpGet]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> GetAllUsers()
    {
        var users = await _userService.GetAllUsersAsync();
        var userDtos = users.Select(u => _userMapper.MapToDto(u));
        return Ok(userDtos);
    }

    [HttpGet("{id}/working-days-report")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> GetUserWorkingDaysReport(int id)
    {
        try
        {
            var report = await _userService.GenerateUserWorkingDaysReport(id);
            return Ok(report);
        }
        catch (Exception ex)
        {
            if (ex.Message == _localizer["UserNotFound"])
            {
                return NotFound(_localizer["UserNotFound", id].Value);
            }
            return BadRequest(ex.Message);
        }
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetUserById(int id)
    {
        var user = await _userService.GetUserByIdAsync(id);
        if (user == null)
        {
            return NotFound(_localizer["UserNotFound", id].Value);
        }
        var userDto = _userMapper.MapToDto(user);
        return Ok(userDto);
    }

    [HttpPost]
    [AllowAnonymous]
    public async Task<IActionResult> AddUser([FromBody] UserDto userDto)
    {
        if (userDto == null)
        {
            return BadRequest(_localizer["InvalidData"].Value);
        }

        try
        {
            var user = _userMapper.MapToEntity(userDto);
            var createdUser = await _userService.AddUserAsync(user);
            var responseDto = _userMapper.MapToDto(createdUser);
            return CreatedAtAction(nameof(GetUserById), new { id = createdUser.UserId }, responseDto);
        }
        catch (Exception ex)
        {
            return Conflict(new { Message = ex.Message });
        }
    }

    [HttpPut("{id}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> UpdateUser(int id, [FromBody] UserUpdateDto userUpdateDto)
    {
        if (userUpdateDto == null)
        {
            return BadRequest(_localizer["InvalidData"].Value);
        }
        try
        {
            await _userService.UpdateUserAsync(id, userUpdateDto, User);
            return NoContent();
        }
        catch (InvalidOperationException ex)
        {
            return Forbid(ex.Message);
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }

    [HttpDelete("{id}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> DeleteUser(int id)
    {
        try
        {
            await _userService.DeleteUserAsync(id, User);
            return NoContent();
        }
        catch (InvalidOperationException ex)
        {
            return Forbid(ex.Message);
        }
    }

    [HttpPost("login")]
    [AllowAnonymous]
    public async Task<IActionResult> Login([FromBody] LoginDto loginDto)
    {
        if (loginDto == null)
        {
            return BadRequest(_localizer["InvalidData"].Value);
        }

        var user = await _userService.Authenticate(loginDto.PhoneNumber, loginDto.Password);

        if (user == null)
        {
            return Unauthorized(_localizer["InvalidCredentials"].Value);
        }

        var userDto = _userMapper.MapToDto(user);
        return Ok(userDto);
    }
}
