using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Threading.Tasks;
using Microsoft.Extensions.Localization;

[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = "Admin")]
public class BackupController : ControllerBase
{
    private readonly BackupService _backupService;
    private readonly IStringLocalizer<SharedResources> _localizer;

    public BackupController(
        BackupService backupService,
        IStringLocalizer<SharedResources> localizer)
    {
        _backupService = backupService;
        _localizer = localizer;
    }

    [HttpPost("create")]
    public async Task<IActionResult> CreateBackup()
    {
        var (success, backupFileName) = await _backupService.CreateBackupAsync();
        if (success)
        {
            return Ok(new { Message = _localizer["BackupCreated"].Value, BackupFile = backupFileName });
        }
        else
        {
            return StatusCode(500, new { Error = backupFileName });
        }
    }

    [HttpGet("list")]
    public IActionResult ListBackups()
    {
        var backups = _backupService.GetAvailableBackups();
        return Ok(backups);
    }

    [HttpPost("restore")]
    public async Task<IActionResult> RestoreBackup([FromQuery] string fileName)
    {
        if (string.IsNullOrEmpty(fileName))
        {
            return BadRequest("Backup file name must be provided.");
        }

        var (success, message) = await _backupService.RestoreBackupAsync(fileName);
        if (success)
        {
            return Ok(new { Message = message });
        }
        else
        {
            return StatusCode(500, new { Error = message });
        }
    }
}
