// src/services/api.ts
import axios from 'axios';

// src/store/auth.ts
import { defineStore } from 'pinia';

interface User {
  userId: number;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  role: string;
}

export const useAuthStore = defineStore('auth', {
  state: () => ({
    user: JSON.parse(localStorage.getItem('user') || 'null') as User | null,
    token: localStorage.getItem('authToken') || null as string | null,
  }),

  getters: {
    isAuthenticated: (state) => !!state.token,
    userFullName: (state) => state.user ? `${state.user.firstName} ${state.user.lastName}` : 'Guest',
    userRole: (state) => state.user?.role,
    isAdmin: (state) => state.user?.role === 'Admin',
    isManager: (state) => state.user?.role === 'Manager',
  },

  actions: {
    loginSuccess(userData: User, base64Token: string) {
      this.user = userData;
      this.token = base64Token;
      localStorage.setItem('user', JSON.stringify(userData));
      localStorage.setItem('authToken', base64Token);
    },

    logout() {
      this.user = null;
      this.token = null;
      localStorage.removeItem('authToken');
      localStorage.removeItem('user');
      if (this.router) {
        this.router.push('/login');
      } else {
        window.location.href = '/login';
      }
    },
  },
});

const apiClient = axios.create({
  baseURL: 'http://localhost:8080/api',
  headers: {
    'Content-Type': 'application/json'
  }
});

apiClient.interceptors.request.use(config => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Basic ${token}`;
  }
  return config;
});

export default apiClient;
