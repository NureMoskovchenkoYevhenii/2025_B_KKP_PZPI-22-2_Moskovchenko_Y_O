<template>
  <header class="app-header">
    <div class="header-content">
      <router-link to="/" class="logo">StaffFlow</router-link>
      <nav v-if="authStore.isAuthenticated" class="main-nav">
        <router-link to="/dashboard">Моніторинг</router-link>
        <router-link to="/my-schedule">Мій графік</router-link>
        <router-link to="/request-change">Створити запит</router-link>
        <router-link v-if="authStore.isAdmin" to="/admin">Admin Panel</router-link>
      </nav>

      <div class="user-actions">
        <div v-if="authStore.isAuthenticated" class="user-info">
          <span>Welcome, {{ authStore.userFullName }}</span>
          <button @click="handleLogout" class="btn-logout">Logout</button>
        </div>
        <router-link v-else to="/login" class="btn btn-primary">Login</router-link>
      </div>
    </div>
  </header>

  <main class="main-content">
    <router-view/>
  </main>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import { useAuthStore } from '@/store/auth';

export default defineComponent({
  setup() {
    const authStore = useAuthStore();

    const handleLogout = () => {
      authStore.logout();
    };

    return {
      authStore,
      handleLogout,
    };
  },
});
</script>

<style scoped>
.app-header {
  background-color: var(--surface-color);
  border-bottom: 1px solid var(--border-color);
  height: 64px;
  padding: 0 2rem;
  position: sticky;
  top: 0;
  z-index: 10;
}

.header-content {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 100%;
  max-width: 1200px;
  margin: 0 auto;
}

.logo {
  font-weight: 700;
  font-size: 1.5rem;
  color: var(--primary-color);
  text-decoration: none;
}

.main-nav {
  display: flex;
  gap: 1.5rem;
}

.main-nav a {
  text-decoration: none;
  color: var(--text-color-secondary);
  font-weight: 500;
  padding: 5px 0;
  border-bottom: 2px solid transparent;
  transition: color 0.2s, border-color 0.2s;
}

.main-nav a:hover {
  color: var(--text-color);
}

.main-nav a.router-link-exact-active {
  color: var(--primary-color);
  border-bottom-color: var(--primary-color);
}

.user-actions {
  display: flex;
  align-items: center;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.btn-logout {
  background: none;
  border: 1px solid var(--border-color);
  color: var(--text-color);
  padding: 0.375rem 0.75rem;
}

.btn-logout:hover {
  background-color: #f8f9fa;
}

.main-content {
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
}
</style>
