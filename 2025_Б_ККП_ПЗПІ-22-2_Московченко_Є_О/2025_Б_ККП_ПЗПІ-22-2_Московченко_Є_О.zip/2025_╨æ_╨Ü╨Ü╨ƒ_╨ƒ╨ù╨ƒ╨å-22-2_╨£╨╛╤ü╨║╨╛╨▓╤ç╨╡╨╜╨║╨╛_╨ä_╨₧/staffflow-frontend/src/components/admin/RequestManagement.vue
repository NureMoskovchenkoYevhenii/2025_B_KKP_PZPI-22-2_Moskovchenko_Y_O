<template>
  <div>
    <h2>Обробка Запитів на Зміни</h2>
    <table v-if="pendingRequests.length">
      <thead>
        <tr>
          <th>ID Запиту</th>
          <th>Користувач</th>
          <th>Тип</th>
          <th>Дати</th>
          <th>Опис</th>
          <th>Дії</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="request in pendingRequests" :key="request.changeRequestId">
          <td>{{ request.changeRequestId }}</td>
          <td>
            <span v-if="request.userChangeRequests && request.userChangeRequests.length > 0 && request.userChangeRequests[0].user">
              {{ request.userChangeRequests[0].user.firstName }} {{ request.userChangeRequests[0].user.lastName }}
            </span>
            <span v-else>
              (Користувача не знайдено)
            </span>
          </td>
          <td>{{ request.dayType.dayTypeName }}</td>
          <td>{{ formatDate(request.startDate) }} - {{ formatDate(request.endDate) }}</td>
          <td>{{ request.description }}</td>
          <td>
            <button class="approve-btn" @click="updateRequestStatus(request.changeRequestId, 'Схвалено')">Схвалити</button>
            <button class="reject-btn" @click="updateRequestStatus(request.changeRequestId, 'Відхилено')">Відхилити</button>
          </td>
        </tr>
      </tbody>
    </table>
    <p v-else>Немає запитів, що потребують обробки.</p>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, onMounted, computed } from 'vue';
import apiClient from '@/services/api';

interface DayType { dayTypeName: string; }
interface User { firstName: string; lastName: string; }
interface UserChangeRequest { user: User; }
interface ChangeRequest {
  changeRequestId: number;
  requestDate: string;
  status: string;
  dayTypeId: number;
  dayType: DayType;
  startDate: string;
  endDate: string;
  description: string;
  userChangeRequests: UserChangeRequest[];
}

export default defineComponent({
  name: 'RequestManagement',
  setup() {
    const allRequests = ref<ChangeRequest[]>([]);

    const fetchRequests = async () => {
      try {
        const response = await apiClient.get('/ChangeRequests');
        allRequests.value = response.data;
      } catch (error) {
        console.error("Помилка завантаження запитів:", error);
      }
    };

    const pendingRequests = computed(() =>
      allRequests.value.filter(req => req.status === 'на опрацюванні')
    );

    const updateRequestStatus = async (requestId: number, newStatus: 'Схвалено' | 'Відхилено') => {
      const originalRequest = allRequests.value.find(r => r.changeRequestId === requestId);
      if (!originalRequest) return;
      const payload = { ...originalRequest, status: newStatus };

      try {
        await apiClient.put(`/ChangeRequests/${requestId}`, payload);
        await fetchRequests();
      } catch (error) {
        console.error(`Помилка оновлення статусу запиту ${requestId}:`, error);
        alert('Не вдалося оновити статус.');
      }
    };

    const formatDate = (dateString: string) => {
      return new Date(dateString).toLocaleDateString('uk-UA');
    };

    onMounted(fetchRequests);

    return {
      pendingRequests,
      updateRequestStatus,
      formatDate,
    };
  },
});
</script>

<style scoped>
table { width: 100%; border-collapse: collapse; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background-color: #f2f2f2; }
button { margin-right: 5px; }
.delete-btn { background-color: #f44336; color: white; border:none; }
.save-btn { background-color: #4CAF50; color: white; border:none; }
.form-group { margin-bottom: 15px; }
.form-group label { display: block; margin-bottom: 5px; }
.form-group input, .form-group select { width: 100%; padding: 8px; box-sizing: border-box; }
.approve-btn { background-color: #4CAF50; color: white; border: none; }
.reject-btn { background-color: #f44336; color: white; border: none; }
</style>
