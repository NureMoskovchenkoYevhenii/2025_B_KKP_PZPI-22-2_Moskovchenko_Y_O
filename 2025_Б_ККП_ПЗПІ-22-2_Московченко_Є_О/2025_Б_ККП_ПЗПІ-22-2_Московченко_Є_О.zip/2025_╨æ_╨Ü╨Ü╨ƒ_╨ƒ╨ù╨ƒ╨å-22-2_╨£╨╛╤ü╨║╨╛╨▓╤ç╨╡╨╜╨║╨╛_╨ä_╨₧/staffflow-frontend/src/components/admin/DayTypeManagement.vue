<template>
  <div>
    <h2>Управління Типами Днів</h2>
    <button class="add-btn" @click="openCreateModal">Додати новий тип дня</button>
    <table v-if="dayTypes.length">
      <thead>
        <tr>
          <th>ID</th>
          <th>Назва</th>
          <th>Дії</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="dayType in dayTypes" :key="dayType.dayTypeId">
          <td>{{ dayType.dayTypeId }}</td>
          <td>{{ dayType.dayTypeName }}</td>
          <td>
            <button class="btn btn-secondary" @click="openEditModal(dayType)">Редагувати</button>
            <button class="delete-btn" @click="deleteDayType(dayType.dayTypeId)">Видалити</button>
          </td>
        </tr>
      </tbody>
    </table>
    <p v-else>Типи днів не знайдено.</p>

    <Modal :isOpen="isModalOpen" @close="closeModal">
      <template #header>
        <h3>{{ isEditing ? 'Редагування' : 'Створення' }} Типу Дня</h3>
      </template>
      <template #default>
        <form v-if="currentDayType" @submit.prevent="saveDayType">
          <div class="form-group">
            <label for="dayTypeName">Назва типу дня:</label>
            <input type="text" id="dayTypeName" v-model="currentDayType.dayTypeName" required />
          </div>
        </form>
      </template>
      <template #footer>
        <button class="btn btn-primary" @click="closeModal">Скасувати</button>
        <button class="save-btn" @click="saveDayType">Зберегти</button>
      </template>
    </Modal>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, onMounted, reactive } from 'vue';
import apiClient from '@/services/api';
import Modal from '@/components/BaseModal.vue';

interface DayTypeDto {
  dayTypeId?: number;
  dayTypeName: string;
}

export default defineComponent({
  name: 'DayTypeManagement',
  components: {
    Modal,
  },
  setup() {
    const dayTypes = ref<DayTypeDto[]>([]);
    const isModalOpen = ref(false);
    const isEditing = ref(false);
    const currentDayType = ref<DayTypeDto | null>(null);

    const fetchDayTypes = async () => {
      try {
        const response = await apiClient.get('/DayTypes');
        dayTypes.value = response.data;
      } catch (error) {
        console.error("Помилка завантаження типів днів:", error);
      }
    };

    const openCreateModal = () => {
      isEditing.value = false;
      currentDayType.value = reactive({ dayTypeName: '' });
      isModalOpen.value = true;
    };

    const openEditModal = (dayType: DayTypeDto) => {
      isEditing.value = true;
      currentDayType.value = reactive({ ...dayType });
      isModalOpen.value = true;
    };

    const closeModal = () => {
      isModalOpen.value = false;
      currentDayType.value = null;
    };

    const saveDayType = async () => {
      if (!currentDayType.value) return;

      try {
        if (isEditing.value) {
          await apiClient.put(`/DayTypes/${currentDayType.value.dayTypeId}`, currentDayType.value);
        } else {
          await apiClient.post('/DayTypes', currentDayType.value);
        }
        await fetchDayTypes();
        closeModal();
      } catch (error) {
        console.error("Помилка збереження типу дня:", error);
        alert("Не вдалося зберегти тип дня.");
      }
    };

    const deleteDayType = async (dayTypeId: number | undefined) => {
      if (typeof dayTypeId === 'undefined') {
        console.error("Cannot delete a day type without an ID.");
        return;
      }

      if (confirm('Ви впевнені, що хочете видалити цей тип дня?')) {
        try {
          await apiClient.delete(`/DayTypes/${dayTypeId}`);
          await fetchDayTypes();
        } catch (error) {
          console.error("Помилка видалення типу дня:", error);
        }
      }
    };

    onMounted(fetchDayTypes);

    return {
      dayTypes,
      isModalOpen,
      isEditing,
      currentDayType,
      openCreateModal,
      openEditModal,
      closeModal,
      saveDayType,
      deleteDayType,
    };
  },
});
</script>

<style scoped>
.add-btn { margin-bottom: 15px; background-color: #007bff; color: white; border: none; padding: 10px 15px; cursor: pointer; border-radius: 4px; }
table { width: 100%; border-collapse: collapse; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background-color: #f2f2f2; }
button { margin-right: 5px; }
.delete-btn { background-color: #f44336; color: white; border:none; }
.save-btn { background-color: #4CAF50; color: white; border:none; }
.form-group { margin-bottom: 15px; }
.form-group label { display: block; margin-bottom: 5px; }
.form-group input { width: 100%; padding: 8px; box-sizing: border-box; }
</style>
