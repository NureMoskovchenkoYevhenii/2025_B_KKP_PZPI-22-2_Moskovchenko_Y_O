<template>
  <div>
    <h2>Управління Графіками</h2>
    <form @submit.prevent="addWorkingDay" class="schedule-form">
      <h3>Додати новий робочий день</h3>

      <div class="form-group">
        <label for="user">Користувач:</label>
        <select id="user" v-model="newScheduleEntry.userId" required>
          <option disabled value="">Виберіть користувача</option>
          <option v-for="user in users" :key="user.userId" :value="user.userId">
            {{ user.firstName }} {{ user.lastName }}
          </option>
        </select>
      </div>

      <div class="form-group">
        <label for="dayType">Тип дня:</label>
        <select id="dayType" v-model="newScheduleEntry.dayTypeId" required>
          <option disabled value="">Виберіть тип</option>
          <option v-for="dayType in dayTypes" :key="dayType.dayTypeId" :value="dayType.dayTypeId">
            {{ dayType.dayTypeName }}
          </option>
        </select>
      </div>

      <div class="form-group">
        <label for="date">Дата:</label>
        <input type="date" id="date" v-model="scheduleDate" required />
      </div>

      <div class="form-group-inline">
        <div class="form-group">
          <label for="startTime">Час початку:</label>
          <input type="time" id="startTime" v-model="scheduleStartTime" required />
        </div>
        <div class="form-group">
          <label for="endTime">Час кінця:</label>
          <input type="time" id="endTime" v-model="scheduleEndTime" required />
        </div>
      </div>

      <button class="btn btn-secondary" type="submit" :disabled="isLoading">Додати до графіка</button>
      <p v-if="error" class="error-message">{{ error }}</p>
      <p v-if="successMessage" class="success-message">{{ successMessage }}</p>
    </form>
  </div>
</template>

<script lang="ts">
import { defineComponent, reactive, ref, onMounted } from 'vue';
import apiClient from '@/services/api';

interface UserDto { userId: number; firstName: string; lastName: string; }
interface DayTypeDto { dayTypeId: number; dayTypeName: string; }

export default defineComponent({
  name: 'ScheduleManagement',
  setup() {
    const users = ref<UserDto[]>([]);
    const dayTypes = ref<DayTypeDto[]>([]);
    const isLoading = ref(false);
    const error = ref('');
    const successMessage = ref('');

    const scheduleDate = ref('');
    const scheduleStartTime = ref('');
    const scheduleEndTime = ref('');
    const newScheduleEntry = reactive({
      userId: '',
      dayTypeId: '',
    });

    const fetchDataForForm = async () => {
      try {
        const [usersResponse, dayTypesResponse] = await Promise.all([
          apiClient.get('/Users'),
          apiClient.get('/DayTypes')
        ]);
        users.value = usersResponse.data;
        dayTypes.value = dayTypesResponse.data;
      } catch (err) {
        error.value = "Не вдалося завантажити дані для форми.";
        console.error(err);
      }
    };

    const addWorkingDay = async () => {
      isLoading.value = true;
      error.value = '';
      successMessage.value = '';

      try {
        const startTime = new Date(`${scheduleDate.value}T${scheduleStartTime.value}`).toISOString();
        const endTime = new Date(`${scheduleDate.value}T${scheduleEndTime.value}`).toISOString();

        const payload = {
          userId: parseInt(newScheduleEntry.userId, 10),
          dayTypeId: parseInt(newScheduleEntry.dayTypeId, 10),
          startTime: startTime,
          endTime: endTime,
        };

        await apiClient.post('/WorkingDays', payload);
        successMessage.value = 'Робочий день успішно додано!';
        Object.assign(newScheduleEntry, { userId: '', dayTypeId: ''});
        scheduleDate.value = '';
        scheduleStartTime.value = '';
        scheduleEndTime.value = '';
      } catch (err) {
        error.value = 'Помилка при додаванні робочого дня.';
        console.error(err);
      } finally {
        isLoading.value = false;
      }
    };

    onMounted(fetchDataForForm);

    return {
      users,
      dayTypes,
      isLoading,
      error,
      successMessage,
      newScheduleEntry,
      scheduleDate,
      scheduleStartTime,
      scheduleEndTime,
      addWorkingDay,
    };
  },
});
</script>

<style scoped>
.schedule-form {
  max-width: 500px;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 8px;
}
.form-group { margin-bottom: 15px; }
.form-group-inline { display: flex; gap: 20px; }
.form-group-inline .form-group { flex: 1; }
.form-group label { display: block; margin-bottom: 5px; }
.form-group input, .form-group select {
  width: 100%;
  padding: 8px;
  box-sizing: border-box;
}
.error-message { color: red; }
.success-message { color: green; }
.btn-secondary {
  color: var(--text-color);
  background-color: #c0d8f0;
  border-color: #bdc7d1;
}
</style>
