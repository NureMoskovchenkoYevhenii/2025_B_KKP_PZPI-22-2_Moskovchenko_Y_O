<template>
  <div>
    <h2>Управління Користувачами</h2>
    <table v-if="users.length">
      <thead>
        <tr>
          <th>ID</th>
          <th>Ім'я</th>
          <th>Прізвище</th>
          <th>Номер телефону</th>
          <th>Роль</th>
          <th>Дії</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="user in users" :key="user.userId">
          <td>{{ user.userId }}</td>
          <td>{{ user.firstName }}</td>
          <td>{{ user.lastName }}</td>
          <td>{{ user.phoneNumber }}</td>
          <td>{{ user.role }}</td>
          <td>
            <button class="btn btn-secondary" @click="openEditModal(user)">Редагувати</button>
            <button class="delete-btn" @click="deleteUser(user.userId)">Видалити</button>
          </td>
        </tr>
      </tbody>
    </table>
    <p v-else>Користувачів не знайдено.</p>
    <BaseModal :isOpen="isModalOpen" @close="closeEditModal">
      <template #header>
        <h3>Редагування Користувача</h3>
      </template>
      <template #default>
        <form v-if="currentUser" @submit.prevent="saveUser">
          <div class="form-group">
            <label for="firstName">Ім'я:</label>
            <input type="text" id="firstName" v-model="currentUser.firstName" required />
          </div>
          <div class="form-group">
            <label for="lastName">Прізвище:</label>
            <input type="text" id="lastName" v-model="currentUser.lastName" required />
          </div>
          <div class="form-group">
            <label for="role">Роль:</label>
            <select id="role" v-model="currentUser.role" required>
              <option value="User">User</option>
              <option value="Admin">Admin</option>
            </select>
          </div>
        </form>
      </template>
      <template #footer>
        <button class="btn btn-secondary" @click="closeEditModal">Скасувати</button>
        <button class="save-btn" @click="saveUser">Зберегти</button>
      </template>
    </BaseModal>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, onMounted } from 'vue';
import apiClient from '../../services/api';
import BaseModal from '../BaseModal.vue';

interface UserDto {
  userId?: number;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  role: string;
}

export default defineComponent({
  name: 'UserManagement',
  components: {
    BaseModal,
  },
  setup() {
    const users = ref<UserDto[]>([]);
    const isModalOpen = ref(false);
    const currentUser = ref<UserDto | null>(null);

    const fetchUsers = async () => {
      try {
        const response = await apiClient.get('/Users');
        users.value = response.data;
      } catch (error) {
        console.error("Помилка завантаження користувачів:", error);
      }
    };

    const openEditModal = (user: UserDto) => {
      currentUser.value = { ...user };
      isModalOpen.value = true;
    };

    const closeEditModal = () => {
      isModalOpen.value = false;
      currentUser.value = null;
    };

    const saveUser = async () => {
      if (!currentUser.value || !currentUser.value.userId) return;

      try {
        const userToUpdate = {
          firstName: currentUser.value.firstName,
          lastName: currentUser.value.lastName,
          role: currentUser.value.role,
        };

        await apiClient.put(`/Users/${currentUser.value.userId}`, userToUpdate);
        await fetchUsers();
        closeEditModal();
      } catch (error) {
        console.error("Помилка оновлення користувача:", error);
        alert("Не вдалося оновити користувача.");
      }
    };

    const deleteUser = async (userId: number | undefined) => {
      if (typeof userId === 'undefined') {
        console.error("Cannot delete user without an ID.");
        return;
      }
      if (confirm('Ви впевнені, що хочете видалити цього користувача?')) {
        try {
          await apiClient.delete(`/Users/${userId}`);
          await fetchUsers();
        } catch (error) {
          console.error("Помилка видалення користувача:", error);
        }
      }
    };

    onMounted(fetchUsers);

    return {
      users,
      isModalOpen,
      currentUser,
      openEditModal,
      closeEditModal,
      saveUser,
      deleteUser,
    };
  },
});
</script>

<style scoped>
table { width: 100%; border-collapse: collapse; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background-color: #f2f2f2; }
button { margin-right: 5px; }
.delete-btn { background-color: #f44336; color: white; border:none; }
.save-btn { background-color: #4CAF50; color: white; border:none; }
.form-group { margin-bottom: 15px; }
.form-group label { display: block; margin-bottom: 5px; }
.form-group input, .form-group select { width: 100%; padding: 8px; box-sizing: border-box; }
.btn-secondary {
  color: var(--text-color);
  background-color: #c0d8f0;
  border-color: #bdc7d1;
}
</style>
