<template>
  <div class="form-wrapper">
    <div class="form-card">
      <h2>Реєстрація в StaffFlow</h2>
      <form @submit.prevent="handleRegister">
        <div class="form-group">
          <label for="firstName">Ім'я</label>
          <input type="text" v-model="form.firstName" required />
          <small v-if="form.firstName && !isFirstNameValid" class="error-text">Ім'я може містити тільки літери.</small>
        </div>
        <div class="form-group">
          <label for="lastName">Прізвище</label>
          <input type="text" v-model="form.lastName" required />
          <small v-if="form.lastName && !isLastNameValid" class="error-text">Прізвище може містити тільки літери.</small>
        </div>
        <div class="form-group">
          <label for="phoneNumber">Номер телефону (Логін)</label>
          <input type="tel" v-mask="'+38 (0##) ###-##-##'" v-model="form.phoneNumber" required />
          <small v-if="form.phoneNumber && !isPhoneNumberValid" class="error-text">Номер має містити 12 цифр.</small>
        </div>
        <div class="form-group">
          <label for="password">Пароль</label>
          <input type="password" id="password" v-model="form.password" required />
        </div>
        <button type="submit" class="btn btn-primary full-width" :disabled="!isFormValid || isLoading">
          {{ isLoading ? 'Реєстрація...' : 'Зареєструватися' }}
        </button>
        <p v-if="error" class="error-message">{{ error }}</p>
        <p v-if="successMessage" class="success-message">{{ successMessage }}</p>
      </form>
      <p class="form-footer">
        Вже маєте акаунт? <router-link to="/login">Увійти</router-link>
      </p>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, reactive, ref, computed } from 'vue';
import { useRouter } from 'vue-router';
import apiClient from '@/services/api';
import { AxiosError } from 'axios';

export default defineComponent({
  name: 'RegisterView',
  setup() {
    const form = reactive({
      firstName: '',
      lastName: '',
      phoneNumber: '',
      password: '',
      role: 'User',
    });

    const error = ref('');
    const successMessage = ref('');
    const isLoading = ref(false);
    const router = useRouter();

    const nameRegex = /^[a-zA-Zа-яА-ЯіІїЇєЄґҐ'-]+$/;

    const isFirstNameValid = computed(() => nameRegex.test(form.firstName));
    const isLastNameValid = computed(() => nameRegex.test(form.lastName));

    const isPhoneNumberValid = computed(() => {
      const digits = form.phoneNumber.replace(/\D/g, '');
      return digits.length === 12;
    });

    const isFormValid = computed(() =>
      isFirstNameValid.value &&
      isLastNameValid.value &&
      isPhoneNumberValid.value &&
      form.password.length > 0
    );

    const handleRegister = async () => {
      isLoading.value = true;
      error.value = '';
      successMessage.value = '';

      try {
        const userToRegister = {
          firstName: form.firstName,
          lastName: form.lastName,
          phoneNumber: form.phoneNumber,
          password: form.password,
          role: form.role,
        };

        await apiClient.post('/Users', userToRegister);

        successMessage.value = 'Реєстрація успішна! Перенаправлення на сторінку входу...';

        setTimeout(() => {
          router.push('/login');
        }, 2000);
      } catch (err) {
        if (err instanceof AxiosError && err.response) {
          error.value = err.response.data?.title || 'Помилка реєстрації. Можливо, такий користувач вже існує.';
        } else {
          error.value = 'Не вдалося підключитися до сервера.';
        }
        console.error('Registration failed:', err);
      } finally {
        isLoading.value = false;
      }
    };

    return {
      form,
      error,
      successMessage,
      isLoading,
      isFirstNameValid,
      isLastNameValid,
      isPhoneNumberValid,
      isFormValid,
      handleRegister,
    };
  },
});
</script>

<style scoped>
.register-container {
  max-width: 400px;
  margin: 50px auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 8px;
}
.form-group {
  margin-bottom: 15px;
}
.error-message {
  color: red;
}
.success-message {
  color: green;
}
.error-text {
  color: var(--danger-color);
  font-size: 0.8rem;
  margin-top: 4px;
}
</style>
