<template>
  <div class="form-wrapper">
    <div class="form-card">
      <h2>Вхід в систему</h2>
      <form @submit.prevent="handleLogin">
        <div class="form-group">
          <label for="phoneNumber">Номер телефону (Логін)</label>
          <input type="tel" id="phoneNumber" v-model="phoneNumber" required autocomplete="username" />
        </div>
        <div class="form-group">
          <label for="password">Пароль</label>
          <input type="password" id="password" v-model="password" required autocomplete="current-password" />
        </div>
        <button type="submit" class="btn btn-primary full-width" :disabled="isLoading">
          {{ isLoading ? 'Вхід...' : 'Увійти' }}
        </button>
        <p v-if="error" class="error-message">{{ error }}</p>
      </form>
      <p class="form-footer">
        Не маєте акаунту? <router-link to="/register">Зареєструватися</router-link>
      </p>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue';
import { useRouter } from 'vue-router';
import apiClient from '@/services/api';
import { AxiosError } from 'axios';
import { useAuthStore } from '@/store/auth';

export default defineComponent({
  name: 'LoginView',
  setup() {
    const phoneNumber = ref('380123456789');
    const password = ref('123456');
    const error = ref('');
    const isLoading = ref(false);
    const router = useRouter();
    const authStore = useAuthStore();

    const handleLogin = async () => {
      isLoading.value = true;
      error.value = '';

      try {
        const response = await apiClient.post('/Users/login', {
          phoneNumber: phoneNumber.value,
          password: password.value,
        });

        console.log('Login successful:', response.data);

        const credentials = `${phoneNumber.value}:${password.value}`;
        const base64Token = btoa(credentials);

        authStore.loginSuccess(response.data, base64Token);

        router.push('/');
      } catch (err) {
        if (err instanceof AxiosError && err.response) {
          error.value = typeof err.response.data === 'string'
            ? err.response.data
            : err.response.data.title || 'Помилка автентифікації.';
        } else {
          error.value = 'Не вдалося підключитися до сервера. Перевірте консоль для деталей.';
        }
        console.error('Login failed:', err);
      } finally {
        isLoading.value = false;
      }
    };

    return {
      phoneNumber,
      password,
      error,
      isLoading,
      handleLogin,
    };
  },
});
</script>

<style scoped>
.login-container {
  max-width: 400px;
  margin: 50px auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 8px;
}
.form-group {
  margin-bottom: 15px;
}
label {
  display: block;
  margin-bottom: 5px;
}
input {
  width: 100%;
  padding: 8px;
  box-sizing: border-box;
}
button {
  width: 100%;
  padding: 10px;
  background-color: #42b983;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
button:disabled {
  background-color: #ccc;
}
.error-message {
  color: red;
  margin-top: 10px;
}
</style>
