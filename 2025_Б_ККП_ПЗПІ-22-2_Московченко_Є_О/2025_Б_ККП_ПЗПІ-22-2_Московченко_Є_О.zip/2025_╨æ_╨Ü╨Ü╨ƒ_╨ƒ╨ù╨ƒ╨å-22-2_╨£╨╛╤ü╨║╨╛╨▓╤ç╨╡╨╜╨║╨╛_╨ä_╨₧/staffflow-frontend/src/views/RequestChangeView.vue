<template>
  <div class="request-container">
    <h1>Створити запит на зміну графіку</h1>
    <form @submit.prevent="submitRequest">
      <div class="form-group">
        <label for="dayType">Тип запиту:</label>
        <select id="dayType" v-model="request.dayTypeId" required>
          <option disabled value="">Виберіть тип</option>
          <option v-for="dayType in dayTypes" :key="dayType.dayTypeId" :value="dayType.dayTypeId">
            {{ dayType.dayTypeName }}
          </option>
        </select>
      </div>

      <div class="form-group">
        <label for="startDate">Дата початку:</label>
        <input type="date" id="startDate" v-model="request.startDate" required />
      </div>

      <div class="form-group">
        <label for="endDate">Дата кінця:</label>
        <input type="date" id="endDate" v-model="request.endDate" required />
      </div>

      <div class="form-group">
        <label for="description">Опис (причина):</label>
        <textarea id="description" v-model="request.description" rows="4" required></textarea>
      </div>

      <button class="btn btn-secondary" type="submit" :disabled="isLoading">Надіслати запит</button>
      <p v-if="error" class="error-message">{{ error }}</p>
      <p v-if="successMessage" class="success-message">{{ successMessage }}</p>
    </form>
  </div>
</template>

<script lang="ts">
import { defineComponent, reactive, ref, onMounted } from 'vue';
import apiClient from '@/services/api';
import { useAuthStore } from '@/store/auth';

interface DayTypeDto {
  dayTypeId: number;
  dayTypeName: string;
}

export default defineComponent({
  name: 'RequestChangeView',
  setup() {
    const authStore = useAuthStore();
    const dayTypes = ref<DayTypeDto[]>([]);
    const isLoading = ref(false);
    const error = ref('');
    const successMessage = ref('');

    const request = reactive({
      dayTypeId: '',
      startDate: '',
      endDate: '',
      description: '',
    });

    const fetchDayTypes = async () => {
      try {
        const response = await apiClient.get('/DayTypes');
        dayTypes.value = response.data.filter((dt: DayTypeDto) => dt.dayTypeName !== 'Робочий');
      } catch (err) {
        console.error("Не вдалося завантажити типи днів:", err);
      }
    };

    const submitRequest = async () => {
      if (!authStore.user) {
        error.value = "Помилка авторизації. Спробуйте увійти знову.";
        return;
      }

      isLoading.value = true;
      error.value = '';
      successMessage.value = '';

      try {
        const payload = {
          ...request,
          userId: authStore.user.userId,
          requestDate: new Date().toISOString(),
          status: 'на опрацюванні'
        };

        await apiClient.post('/ChangeRequests', payload);
        successMessage.value = 'Ваш запит успішно надіслано!';
        Object.assign(request, { dayTypeId: '', startDate: '', endDate: '', description: '' });
      } catch (err) {
        error.value = 'Не вдалося надіслати запит. Спробуйте ще раз.';
        console.error("Помилка створення запиту:", err);
      } finally {
        isLoading.value = false;
      }
    };

    onMounted(fetchDayTypes);

    return {
      request,
      dayTypes,
      isLoading,
      error,
      successMessage,
      submitRequest,
    };
  },
});
</script>

<style scoped>
.request-container { max-width: 600px; margin: auto; padding: 20px; }
.form-group { margin-bottom: 15px; }
.form-group label { display: block; margin-bottom: 5px; }
.form-group input, .form-group select, .form-group textarea {
  width: 100%;
  padding: 8px;
  box-sizing: border-box;
}
.error-message { color: red; }
.success-message { color: green; }
</style>
