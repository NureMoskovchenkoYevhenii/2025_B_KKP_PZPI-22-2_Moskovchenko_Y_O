<template>
  <div class="admin-panel">
    <h1>Панель Адміністратора</h1>
    <div class="tabs">
      <button @click="activeTab = 'users'" :class="{ active: activeTab === 'users' }">Користувачі</button>
      <button @click="activeTab = 'dayTypes'" :class="{ active: activeTab === 'dayTypes' }">Типи Днів</button>
      <button @click="activeTab = 'requests'" :class="{ active: activeTab === 'requests' }">Запити</button>
      <button @click="activeTab = 'schedules'" :class="{ active: activeTab === 'schedules' }">Графіки</button>
    </div>

    <div class="tab-content">
      <div v-if="activeTab === 'users'">
        <UserManagement />
      </div>
      <div v-if="activeTab === 'dayTypes'">
        <DayTypeManagement />
      </div>
      <div v-if="activeTab === 'requests'">
        <RequestManagement />
      </div>
      <div v-if="activeTab === 'schedules'">
        <ScheduleManagement />
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue';
import UserManagement from '@/components/admin/UserManagement.vue';
import DayTypeManagement from '@/components/admin/DayTypeManagement.vue';
import RequestManagement from '@/components/admin/RequestManagement.vue';
import ScheduleManagement from '@/components/admin/ScheduleManagement.vue';

export default defineComponent({
  name: 'AdminView',
  components: {
    UserManagement,
    DayTypeManagement,
    RequestManagement,
    ScheduleManagement,
  },
  setup() {
    const activeTab = ref('users');
    return { activeTab };
  },
});
</script>

<style scoped>
.admin-panel { padding: 20px; }
.tabs button {
  padding: 10px 15px;
  border: 1px solid #ccc;
  background-color: #f0f0f0;
  cursor: pointer;
}
.tabs button.active {
  background-color: #42b983;
  color: white;
}
.tab-content {
  margin-top: 20px;
  border: 1px solid #ccc;
  padding: 20px;
}
</style>
