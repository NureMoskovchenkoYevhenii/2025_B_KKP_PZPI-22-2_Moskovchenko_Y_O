<template>
  <div class="dashboard">
    <header class="dashboard-header">
      <h1>Панель Моніторингу</h1>
      <p>Останні показники з IoT-пристроїв у реальному часі</p>
    </header>

    <div v-if="isLoading" class="loading-state">Завантаження даних...</div>
    <div v-else-if="error" class="error-state">{{ error }}</div>
    <div v-else class="data-container">
      <div class="cards-grid">
        <div class="card" :class="{ 'alert': isTempAlert }">
          <div class="card-header">
            <h3>Температура</h3>
            <span class="status-indicator" :class="{ 'alert': isTempAlert, 'ok': !isTempAlert }"></span>
          </div>
          <div class="card-body">
            <p class="value">{{ latestData?.temperature?.toFixed(2) ?? 'N/A' }} °C</p>
            <p class="status-text">{{ isTempAlert ? 'Поза нормою!' : 'В нормі' }}</p>
          </div>
        </div>
        <div class="card" :class="{ 'alert': isHumidityAlert }">
          <div class="card-header">
            <h3>Вологість</h3>
            <span class="status-indicator" :class="{ 'alert': isHumidityAlert, 'ok': !isHumidityAlert }"></span>
          </div>
          <div class="card-body">
            <p class="value">{{ latestData?.humidity?.toFixed(2) ?? 'N/A' }} %</p>
            <p class="status-text">{{ isHumidityAlert ? 'Поза нормою!' : 'В нормі' }}</p>
          </div>
        </div>
      </div>

      <div class="card chart-card" v-if="chartData.labels.length">
        <div class="card-header">
          <h3>Історія показників та подій</h3>
        </div>
        <div class="card-body chart-container">
          <Line :data="chartData" :options="chartOptions" />
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, onMounted, onUnmounted, computed } from 'vue';
import apiClient from '@/services/api';
import { Line } from 'vue-chartjs';
import {
  Chart as ChartJS, Title, Tooltip, Legend, LineElement, CategoryScale, LinearScale, PointElement, ChartData, ChartOptions
} from 'chart.js';
import annotationPlugin from 'chartjs-plugin-annotation';

ChartJS.register(Title, Tooltip, Legend, LineElement, CategoryScale, LinearScale, PointElement, annotationPlugin);

interface SensorData {
  id: number;
  timestamp: string;
  temperature: number;
  humidity: number;
  isTemperatureAdjustmentEnabled: boolean;
  isHumidityAdjustmentEnabled: boolean;
}

interface CustomAnnotation {
  type: 'line';
  xMin: number;
  xMax: number;
  borderColor: string;
  borderWidth: number;
  borderDash?: number[];
  label: {
    content: string;
    display: boolean;
    position: 'start' | 'end';
    backgroundColor: string;
  };
}

export default defineComponent({
  name: 'DashboardView',
  components: { Line },
  setup() {
    const allData = ref<SensorData[]>([]);
    const isLoading = ref(true);
    const error = ref('');
    const latestData = ref<SensorData | null>(null);
    let intervalId: number;

    const fetchData = async () => {
      try {
        const response = await apiClient.get<SensorData[]>('/SensorData');
        const sortedData = response.data.sort((a: SensorData, b: SensorData) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
        allData.value = sortedData;
        if (sortedData.length > 0) {
          latestData.value = sortedData[sortedData.length - 1];
        }
        error.value = '';
      } catch (err) {
        console.error("Помилка завантаження даних сенсорів:", err);
        error.value = 'Не вдалося завантажити дані.';
      } finally {
        isLoading.value = false;
      }
    };

    const isTempAlert = computed(() => latestData.value?.isTemperatureAdjustmentEnabled ?? false);
    const isHumidityAlert = computed(() => latestData.value?.isHumidityAdjustmentEnabled ?? false);

    const chartData = computed((): ChartData<'line'> => ({
      labels: allData.value.map(d => new Date(d.timestamp).toLocaleTimeString('uk-UA')),
      datasets: [
        {
          label: 'Температура (°C)',
          borderColor: '#E57373',
          backgroundColor: 'rgba(229, 115, 115, 0.1)',
          data: allData.value.map(d => d.temperature),
          tension: 0.1,
          fill: true,
        },
        {
          label: 'Вологість (%)',
          borderColor: '#64B5F6',
          backgroundColor: 'rgba(100, 181, 246, 0.1)',
          data: allData.value.map(d => d.humidity),
          tension: 0.1,
          fill: true,
        }
      ]
    }));

    const chartOptions = computed((): ChartOptions<'line'> => {
      const annotations: CustomAnnotation[] = [];
      for (let i = 1; i < allData.value.length; i++) {
        const prev = allData.value[i - 1];
        const curr = allData.value[i];
        if (curr.isTemperatureAdjustmentEnabled && !prev.isTemperatureAdjustmentEnabled) {
          annotations.push({
            type: 'line',
            xMin: i,
            xMax: i,
            borderColor: 'rgba(229, 115, 115, 0.7)',
            borderWidth: 2,
            label: {
              content: 'Вкл. темп.',
              display: true,
              position: 'start',
              backgroundColor: 'rgba(229, 115, 115, 0.7)'
            }
          });
        }
        if (curr.isHumidityAdjustmentEnabled && !prev.isHumidityAdjustmentEnabled) {
          annotations.push({
            type: 'line',
            xMin: i,
            xMax: i,
            borderColor: 'rgba(100, 181, 246, 0.7)',
            borderWidth: 2,
            borderDash: [6, 6],
            label: {
              content: 'Вкл. вол.',
              display: true,
              position: 'end',
              backgroundColor: 'rgba(100, 181, 246, 0.7)'
            }
          });
        }
      }

      return {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'top' },
          title: { display: false },
          annotation: {
            annotations: annotations
          }
        }
      };
    });

    onMounted(() => {
      fetchData();
      intervalId = window.setInterval(fetchData, 10000);
    });

    onUnmounted(() => {
      clearInterval(intervalId);
    });

    return { isLoading, error, latestData, isTempAlert, isHumidityAlert, chartData, chartOptions };
  },
});
</script>

<style scoped>
.dashboard-header {
  margin-bottom: 2rem;
}
.dashboard-header h1 {
  font-size: 2rem;
  font-weight: 700;
}
.dashboard-header p {
  font-size: 1rem;
  color: var(--text-color-secondary);
}
.cards-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
}
.card {
  background-color: var(--surface-color);
  border-radius: var(--border-radius);
  box-shadow: var(--box-shadow);
  border: 1px solid var(--border-color);
  transition: box-shadow 0.2s ease-in-out;
}
.card:hover {
  box-shadow: 0 8px 15px rgba(0,0,0,0.1);
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 1.5rem;
  border-bottom: 1px solid var(--border-color);
}
.card-header h3 {
  margin: 0;
  font-size: 1rem;
  font-weight: 600;
}
.status-indicator {
  width: 12px;
  height: 12px;
  border-radius: 50%;
}
.status-indicator.ok { background-color: var(--success-color); }
.status-indicator.alert { background-color: var(--danger-color); }
.card-body {
  padding: 1.5rem;
  text-align: center;
}
.card-body .value {
  font-size: 3rem;
  font-weight: 700;
  margin: 0;
  color: var(--text-color);
}
.card-body .status-text {
  font-size: 1rem;
  font-weight: 500;
  margin-top: 0.5rem;
}
.card.ok .status-text { color: var(--success-color); }
.card.alert .status-text { color: var(--danger-color); }

.chart-card {
  margin-top: 2rem;
}
.chart-container {
  position: relative;
  height: 400px;
  padding: 1rem;
}
.loading-state, .error-state {
  text-align: center;
  padding: 3rem;
  font-size: 1.2rem;
  color: var(--text-color-secondary);
}
</style>
