<template>
  <div class="schedule-container">
    <h1>Мій Робочий Графік</h1>
    <div v-if="isLoading">Завантаження...</div>
    <div v-else-if="error">{{ error }}</div>
    <div v-else-if="schedule.length > 0">
      <div v-for="day in groupedSchedule" :key="day.date" class="day-group">
        <h3>{{ formatDate(day.date) }}</h3>
        <ul>
          <li v-for="entry in day.entries" :key="entry.userWorkingDayId">
            <strong>{{ entry.workingDay.dayType.dayTypeName }}:</strong>
            {{ formatTime(entry.workingDay.startTime) }} - {{ formatTime(entry.workingDay.endTime) }}
          </li>
        </ul>
      </div>
    </div>
    <p v-else>У вас немає запланованих робочих днів.</p>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, onMounted, computed } from 'vue';
import apiClient from '@/services/api';

interface DayType {
  dayTypeId: number;
  dayTypeName: string;
}

interface WorkingDay {
  workingDayId: number;
  startTime: string;
  endTime: string;
  dayTypeId: number;
  dayType: DayType;
}

interface ScheduleEntry {
  userWorkingDayId: number;
  userId: number;
  workingDayId: number;
  workingDay: WorkingDay;
}

export default defineComponent({
  name: 'MyScheduleView',
  setup() {
    const schedule = ref<ScheduleEntry[]>([]);
    const isLoading = ref(true);
    const error = ref('');

    const fetchSchedule = async () => {
      try {
        const response = await apiClient.get('/UserWorkingDays/my-schedule');
        schedule.value = response.data;
      } catch (err) {
        error.value = 'Не вдалося завантажити графік.';
        console.error(err);
      } finally {
        isLoading.value = false;
      }
    };

    const groupedSchedule = computed(() => {
      const groups: { [key: string]: { date: string, entries: ScheduleEntry[] } } = {};
      schedule.value.forEach(entry => {
        const date = new Date(entry.workingDay.startTime).toLocaleDateString('uk-UA');
        if (!groups[date]) {
          groups[date] = { date: entry.workingDay.startTime, entries: [] };
        }
        groups[date].entries.push(entry);
      });
      return Object.values(groups);
    });

    const formatDate = (dateString: string) => {
      return new Date(dateString).toLocaleDateString('uk-UA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    };

    const formatTime = (dateString: string) => {
      return new Date(dateString).toLocaleTimeString('uk-UA', { hour: '2-digit', minute: '2-digit' });
    };

    onMounted(fetchSchedule);

    return {
      schedule,
      isLoading,
      error,
      groupedSchedule,
      formatDate,
      formatTime
    };
  },
});
</script>

<style scoped>
.schedule-container { padding: 20px; max-width: 800px; margin: auto; }
.day-group {
  margin-bottom: 20px;
  padding: 15px;
  border: 1px solid #eee;
  border-radius: 8px;
}
ul { list-style-type: none; padding: 0; }
li { padding: 5px 0; }
</style>
