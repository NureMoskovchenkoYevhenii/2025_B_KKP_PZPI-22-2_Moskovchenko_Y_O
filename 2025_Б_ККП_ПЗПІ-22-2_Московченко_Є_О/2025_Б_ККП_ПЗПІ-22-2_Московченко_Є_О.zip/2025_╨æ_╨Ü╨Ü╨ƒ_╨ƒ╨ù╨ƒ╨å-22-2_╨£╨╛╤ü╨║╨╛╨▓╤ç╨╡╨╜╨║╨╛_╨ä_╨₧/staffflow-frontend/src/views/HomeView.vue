<template>
  <div class="home">
    <div class="hero">
      <img alt="StaffFlow logo" src="../assets/logo.png">
      <h1>Ласкаво просимо до StaffFlow</h1>
      <p>Ваше комплексне рішення для управління мережею фастфуд-закладів</p>
    </div>

    <div class="features">
      <div class="feature-card">
        <h3>Управління персоналом</h3>
        <p>Спрощуйте створення робочих графіків, обробляйте запити на зміни та відстежуйте відвідуваність в одному місці.</p>
      </div>
      <div class="feature-card">
        <h3>IoT Моніторинг</h3>
        <p>Автоматично відстежуйте температуру та вологість у ключових зонах, щоб забезпечити якість та безпеку продуктів.</p>
      </div>
      <div class="feature-card">
        <h3>Аналітика та Звіти</h3>
        <p>Отримуйте деталізовані звіти про діяльність персоналу та стан умов зберігання для прийняття обґрунтованих рішень.</p>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue';

export default defineComponent({
  name: 'HomeView',
});
</script>

<style scoped>
.home {
  text-align: center;
  padding: 20px;
}

.hero {
  margin-bottom: 40px;
}

.hero img {
  width: 150px;
  height: 150px;
}

.hero h1 {
  font-size: 2.5rem;
  margin: 20px 0 10px;
}

.hero p {
  font-size: 1.2rem;
  color: #666;
}

.features {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
  max-width: 900px;
  margin: auto;
}

.feature-card {
  border: 1px solid #eee;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

.feature-card h3 {
  color: #42b983;
}
</style>